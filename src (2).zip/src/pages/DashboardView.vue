<template>
  <div class="p-6 font-sans">

    <!-- Header Section -->
    <PageHeader title="Halo, Bendahara! 👋" subtitle="Ini ringkasan kas kelas minggu ke-4.">
      <template #action>
        <button
          class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium text-sm transition-colors flex items-center gap-2 shadow-sm">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
            class="w-5 h-5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Catat Pemasukan
        </button>
      </template>
    </PageHeader>

    <!-- Stats Grid (Reusable Components) -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">

      <!-- Total Saldo -->
      <StatCard title="Total Saldo Kas" value="Rp 450.000" iconBgClass="bg-emerald-50"
        iconColorClass="text-emerald-600">
        <template #icon>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
            stroke="currentColor" class="w-7 h-7">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 9m18 0V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v3" />
          </svg>
        </template>
      </StatCard>

      <!-- Pemasukan Minggu Ini -->
      <StatCard title="Pemasukan (Minggu Ini)" value="Rp 80.000" iconBgClass="bg-blue-50"
        iconColorClass="text-blue-600">
        <template #icon>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
            stroke="currentColor" class="w-7 h-7">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
          </svg>
        </template>
      </StatCard>

      <!-- Pengeluaran Minggu Ini -->
      <StatCard title="Pengeluaran (Minggu Ini)" value="Rp 15.000" iconBgClass="bg-rose-50"
        iconColorClass="text-rose-600">
        <template #icon>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
            stroke="currentColor" class="w-7 h-7">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M2.25 6L9 12.75l4.286-4.286a11.948 11.948 0 014.306 6.43l.776 2.898m0 0l3.182-5.511m-3.182 5.51l-5.511-3.181" />
          </svg>
        </template>
      </StatCard>

      <!-- Total Siswa Nunggak -->
      <StatCard title="Siswa Belum Bayar" value="4 Orang" iconBgClass="bg-amber-50" iconColorClass="text-amber-600">
        <template #icon>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
            stroke="currentColor" class="w-7 h-7">
            <path stroke-linecap="round" stroke-linejoin="round"
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </template>
      </StatCard>

    </div>

    <!-- Main Content Section: Tabel Tunggakan & Aktivitas -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <UnpaidStudentsTable :students="unpayableStudents" @view-all="handleViewAllStudents"
        @mark-paid="handleMarkPaid" />

      <RecentActivityPanel :activities="recentActivities" @view-log="handleViewLog" />
    </div>
  </div>
</template>

<script setup>
// Menggunakan relative path
import StatCard from '../components/ui/StatCard.vue'
import PageHeader from '../components/ui/PageHeader.vue'
import UnpaidStudentsTable from '../components/ui/UnpaidStudentsTable.vue'
import RecentActivityPanel from '../components/ui/RecentActivityPanel.vue'

// Ganti data dummy ini nanti dengan data teman sekelas yang asli
const unpayableStudents = [
  { id: 1, name: 'Budi Santoso', initials: 'BS', weeks: 2 },
  { id: 2, name: 'Siti Aminah', initials: 'SA', weeks: 1 },
  { id: 3, name: 'Rizky Pratama', initials: 'RP', weeks: 3 },
  { id: 4, name: 'Dewi Lestari', initials: 'DL', weeks: 1 },
]

const recentActivities = [
  { id: 1, type: 'in', desc: 'Ahmad membayar kas minggu ke-4', time: 'Hari ini, 09:30' },
  { id: 2, type: 'in', desc: 'Fajar membayar kas minggu ke-4', time: 'Kemarin, 14:15' },
  { id: 3, type: 'out', desc: 'Beli spidol whiteboard (2 pcs)', time: 'Senin, 10:00' },
  { id: 4, type: 'in', desc: 'Rina melunasi tunggakan 2 minggu', time: 'Senin, 08:20' },
]

function handleViewAllStudents() {
  // TODO: arahkan ke halaman daftar siswa lengkap
}

function handleMarkPaid(studentId) {
  // TODO: update status siswa jadi lunas (misalnya panggil Firestore di sini)
  console.log('Tandai lunas untuk siswa id:', studentId)
}

function handleViewLog() {
  // TODO: arahkan ke halaman buku kas
}
</script>